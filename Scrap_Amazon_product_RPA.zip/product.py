#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import pandas as pd
from bs4 import BeautifulSoup as bs
import sys
import os
import pyautogui
import time
import codecs

def presskey(keyname,num,delay):

    for n in range(0,num):
        pyautogui.press(keyname)
        time.sleep(delay)		

#Update input filename below
Input_filename = "asin.xlsx"

#convert excel sheet into a dataframe
df = pd.read_excel(Input_filename,sheet_name='Sheet1')

ASIn = []
Title = []
prc = []
dprc = []
stock = []
dstock = []
inven = []

driver = webdriver.Chrome(executable_path=os.path.join(os.getcwd(),'drivers\\chromedriver.exe'))    

#reading values from a dataframe
links = df['ASIN'].values.T.tolist()	

c = 0
for i in links:
    
    asin = (i.strip())
    driver.get("https://www.amazon.in/dp/" + asin)
    time.sleep(5)	
    '''
    print(driver.find_element_by_id('priceblock_ourprice').text)
    print(driver.find_element_by_id('availability').text)	
    #print(driver.find_element_by_id('expiryDate_feature_div').text)	
    print(driver.find_element_by_id('sellerProfileTriggerId').text)	
    print(driver.find_element_by_id('productTitle').text)	'''	
	
    ASIn.append(asin)	
	
    try:
        Title.append(driver.find_element_by_id('productTitle').text)
    except:
        Title.append("")	
	
    try:
        prc.append(driver.find_element_by_id('priceblock_ourprice').text)
    except:
        prc.append("")

    try:
        dprc.append(driver.find_element_by_id('priceblock_dealprice').text)
    except:
        dprc.append("")			
	
    try:
        stock.append(driver.find_element_by_id('availability').text)
    except:
        stock.append("")

    try:
        dstock.append(driver.find_element_by_id('deal_availability').text)
    except:
        dstock.append("")		

    try:
        inven.append(driver.find_element_by_id('sellerProfileTriggerId').text) 
    except:
        inven.append("")		
	
driver.close()	
	
df = pd.DataFrame({"ASIN":ASIn,"Product Title":Title,"Price":prc,"Deal Price":dprc,"Stock status":stock,"Deal Stock status":dstock,"Inventory":inven})
df.to_excel("output.xlsx",index=False)
