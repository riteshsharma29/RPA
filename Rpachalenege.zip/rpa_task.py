#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import sys
import os


#driver.find_element_by_xpath("//label[text()='Address']/following-sibling::input").send_keys("sample address")

#Update input filename below
Input_filename = "RPA_challenge.xlsx"

#convert excel sheet into a dataframe
df = pd.read_excel(Input_filename,sheet_name='Sheet1')

#reading values from a dataframe
name = df['First Name'].values.T.tolist()
lname = df['Last Name'].values.T.tolist()
company = df['Company Name'].values.T.tolist()
role = df['Role in Company'].values.T.tolist()
addrs = df['Address'].values.T.tolist()
eml = df['Email'].values.T.tolist()
Phone = df['Phone Number'].values.T.tolist()

#Specify chromedriver.exe windows path
driver = webdriver.Chrome(executable_path=os.path.join(os.getcwd(),'drivers\\chromedriver.exe'))    
driver.get("http://rpachallenge.com/")
driver.maximize_window()

for i in range(0,len(name)):

    if i==0: driver.find_element_by_id("start").click()
    driver.find_element_by_xpath("//label[text()='First Name']/following-sibling::input").send_keys(name[i])
    driver.find_element_by_xpath("//label[text()='Last Name']/following-sibling::input").send_keys(lname[i])
    driver.find_element_by_xpath("//label[text()='Company Name']/following-sibling::input").send_keys(company[i])
    driver.find_element_by_xpath("//label[text()='Role in Company']/following-sibling::input").send_keys(role[i])	
    driver.find_element_by_xpath("//label[text()='Address']/following-sibling::input").send_keys(addrs[i])		
    driver.find_element_by_xpath("//label[text()='Email']/following-sibling::input").send_keys(eml[i])	
    driver.find_element_by_xpath("//label[text()='Phone Number']/following-sibling::input").send_keys(Phone[i])		
    driver.find_element_by_xpath("//input[@type='submit']").click()



