#!/usr/bin/python

'''
https://www.youtube.com/watch?v=qIOlXRDweuI
'''

from selenium import webdriver
import pandas as pd
import codecs
import os
import time
import sys
import pyautogui
import shutil
import glob
import pandas as pd
import natsort

dir_path = os.getcwd()
#update your email & password for the
userid = 'ritesh.sharma29@gmail.com'
password = ''
report_year = input()

#function to concat monthly reports
def concat_csv(w):
    os.chdir("Monthly_reports")
    extension = 'csv'
    all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
    sorted_files = natsort.natsorted(all_filenames,reverse=False)
    # combine all files in the list
    combined_csv = pd.concat([pd.read_csv(f) for f in sorted_files],sort=True)
    # export to csv
    combined_csv.to_csv(w + "_2018.csv", index=False, encoding='utf-8')
    shutil.move(w + "_2018.csv",dir_path + "\\Yearly_reports")
    os.chdir(dir_path)
    #removing Monthly_reports for that particular WI
    shutil.rmtree("Monthly_reports")

def presskey(keyname,num,delay):

    for n in range(0,num):
        pyautogui.press(keyname)
        time.sleep(delay)

driver = webdriver.Chrome(executable_path=os.path.join(os.getcwd(),'drivers\\chromedriver.exe'))   
driver.get("https://acme-test.uipath.com/account/login")
driver.maximize_window()

username = driver.find_element_by_id("email")
username.send_keys(userid)

#Provide password
passwd  = driver.find_element_by_id("password")
passwd.send_keys(password)

#Click the Log In Button
driver.find_element_by_id("buttonLogin").click()

#pass end key to load the page till end
presskey('end',1,1)	

driver.find_element_by_xpath('//button[text()=" Reports"]').click()
presskey('tab',1,0.25)	
presskey('enter',1,0.25)

#creating Yearly directory
if os.path.isdir('Yearly_reports'):
    pass
else:
    os.mkdir('Yearly_reports')

#List of Work items for which need to generate yearly report
wi = ["FR065748","RU567434","IT754893"]
#driver.find_element_by_id("vendorTaxID").send_keys("FR065748")

for w in wi:
    if os.path.isdir('Monthly_reports'):
        pass
    else:
        os.mkdir('Monthly_reports')
    driver.find_element_by_id("vendorTaxID").send_keys(w)
    for i in range(0,12):
        #click month dropdown
        driver.find_element_by_xpath('//*[@class="filter-option pull-left"]').click()
        #select Month by passing below keystrokes
        presskey('down',1,0.25)
        presskey('enter',1,0.25)
        if i == 0:
            #select year by passing below keystrokes (once) as its common for all items
            presskey('tab',1,0.25)
            presskey('enter',1,0.25)
            presskey('down',2,0.25)
            presskey('enter',1,0.25)
        try:
            driver.find_element_by_id('buttonDownload').click()
            time.sleep(3)
            shutil.move("C:\\Users\\Ritesh Sharma\\Downloads\\Report-" + w + "-" + str(i+1) + ".csv","Monthly_reports")
        except:
            presskey('enter', 1, 0.25)
            time.sleep(2)
            continue

    #call concat_csv function for
    concat_csv(w)
    os.chdir(dir_path)
    driver.refresh()
    time.sleep(2)
#logout from the system (Selecting URL text example)
driver.find_element_by_partial_link_text('Log Out').click()
#Close the browser
driver.close()












