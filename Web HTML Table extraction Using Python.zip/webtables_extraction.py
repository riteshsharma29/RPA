#! /usr/bin/python3

import pandas as pd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl import __version__
import codecs
import sys
import os
import xlsxwriter

'''
print ("")
print ("")
print ("")
print ("####################### HELP ########################")
print ('Example USAGE : ./task.py "URL" "output.xlsx"')
print ('Example USAGE : ./task.py "https://www.wcpss.net/domain/6832" "output.xlsx"')
print ("####################### HELP ########################")
print ("")
print ("")
print ("")
'''

url = sys.argv[1]
output = sys.argv[2]

try:
	df = pd.read_html(url)
except:
	print("HTML tables not found on the webpage")
	sys.exit()

def pd_html_excel():

    #Create Excel Workbook
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet()
    workbook.close()	

    book = load_workbook(output)
    writer = ExcelWriter(output, engine='openpyxl')     
    writer.book = book
    writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

    for x in range(0,len(df)):

        df[x].to_excel(writer,sheet_name="table_" + str(x),index=False,header=True)
    
    writer.save()    
    print ("Success !!! Please check output xlsx Excel file file for extracted tables from the webpage." + '\n' + '\n')

pd_html_excel()