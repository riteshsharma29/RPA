1]Create folder in linkedin say in d:\linkedin
2]Keep drivers folder in d:\linkedin\drivers
3]keep add_connection.py file in d:\linkedin
3]Open config.py in text editor and update linkedin username,linkedin password,search string,startpage,endpage and save te file
4]If python37 is kept in c: then open cmd and type below commands and press enter.
d:
cd linkedin
c:\python37\pyton.exe add_connection.py 

OR

4]If python37 is kept in d: then open cmd and type below commands and press enter.
d:
cd linkedin
d:\python37\pyton.exe add_connection.py 