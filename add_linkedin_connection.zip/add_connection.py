#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup as bs
import pandas as pd
import codecs
import os
import time
import sys
import getpass
import pyautogui
import config
import datetime


#https://stackoverflow.com/questions/55737390/selecting-an-item-from-the-dropdown-menu-of-a-list-using-python-selenium
#https://stackoverflow.com/questions/57289105/how-to-click-on-all-connect-button-in-linkedin-with-python-selenium


file = codecs.open("dump.txt",encoding='utf-8',mode='w')
file.write("Start Time " + str(datetime.datetime.now()) + '\n')

userid = config.user
password = config.passw
stringsearch = config.search
startpage = config.spage
endpage = config.epage

def presskey(keyname,num,delay):

    for n in range(0,num):
        pyautogui.press(keyname)
        time.sleep(delay)

driver = webdriver.Chrome(executable_path=os.path.join(os.getcwd(),'drivers\\chromedriver.exe'))   
driver.get("https://www.linkedin.com/login?trk=guest_homepage-basic_nav-header-signin")
driver.maximize_window()

username = driver.find_element_by_id("username")
username.send_keys(userid)

#Provide password
passwd  = driver.find_element_by_id("password")
passwd.send_keys(password)

presskey('tab',2,1)		
presskey('enter',1,1)
time.sleep(8)

c = 0
for pg in range(startpage,int(endpage) + 1):
    surl = "https://www.linkedin.com/search/results/all/?keywords=" + stringsearch + "&origin=HISTORY&page=" + str(pg)
    driver.get(surl)
    time.sleep(8)	
    connect_buttons = driver.find_elements_by_xpath("//button[text()='Connect']")
    #print(connect_buttons)
    for connect_button in connect_buttons:
        #print(connect_button.get_attribute("aria-label"))	
        connect_button.click()
        c += 1 		
        presskey('tab',3,1)		
        presskey('enter',1,1)	
        time.sleep(2)
driver.close()		
file.write("Total Connections added are " + str(c) + '\n')
file.write("End Time " + str(datetime.datetime.now()) + '\n')
startt = datetime.datetime.now()
startt = str(startt)
logfile = "Connection_Sent_Log_" + startt.split()[0] + "_" + startt.split()[1] + ".txt"
logfile = logfile.replace(":",".")
file.close()
os.rename('dump.txt',logfile)
 
								
								
				
		
		