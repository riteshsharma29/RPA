#!/usr/bin/python

#Update your Linkedin ID within ' quotes below
user='name.surname@gmail.com'

#Update your Linkedin password within ' quotes below
passw = 'abcd'

#Update Linkedin search string within ' quotes below eg recruiter%2C%20netherlands OR recruiter%2C%20sweden 
search = 'recruiter%2C%20netherlands'

#Update start page
spage = 2

#Update end page
epage = 4